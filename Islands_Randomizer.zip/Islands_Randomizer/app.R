#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

source("Generate_List_of_Houses.R")

# Define UI for application that draws a histogram
ui <- fluidPage(

    numericInput("n", "Sample Size", 1),
    
    downloadButton("output.data", "Download")
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    output$output.data = downloadHandler(
        filename = "Islands Sample.csv",
        content = function(file){
            data = get.sample(input$n)
            write.csv(data, file, row.names = F)
        }
    )
}

# Run the application 
shinyApp(ui = ui, server = server)
